package t4a2;

import java.util.Scanner;

public class T4A2 {

    public static void main(String[] args) {
       //Ejercicio1(); 
       //Ejercicio2();
       Ejercicio3();
       //Ejercicio4();
    }
    
    // Dise�ar una aplicacion que muestre las tablas de multiplicar del 1 al 10.
    
    public static void Ejercicio1(){
    
        Scanner scanner = new Scanner (System.in);  
        for(int i = 1; i < 11; i++){
            for(int j = 1; j < 11; j++){
                System.out.println(i + "x" + j + "\n" + " = " + (1 * j));
            }
        }
        }
    
    //Realizar un programa en Java que pida un n�mero x, y nos diga cu�ntos
    //n�meros hay entre 1 y x que son primos.
    
    public static void Ejercicio2(){
        
        Scanner scanner = new Scanner (System.in);  
        
        int N, i, j;
        
        do{ 
            System.out.print("Introduce un numero: ");
            N = scanner.nextInt();
        } while (N <= 0);
        System.out.println("Numeros primos dedes 1 hasta "+ N);
        
        for (j = 2; j <= N; j++){
        i = 2;
            while (j % i !=0){
            i++;
            }
            if( i == j){
            System.out.println(j);
            }
        }
            
            
            
            }
    
    //Realizar un programa en Java que pida un n�mero x, y nos diga cu�ntos
    //n�meros hay entre 1 y x, cu�ntos pares y cu�ntos impares.
    
    public static void Ejercicio3(){
    Scanner scanner = new Scanner (System.in);
    
    int N, i, j,p;
        
        do{ 
            System.out.print("Introduce un numero: ");
            N = scanner.nextInt();
        } while (N <= 0);
        System.out.println("Numeros impares dedes 1 hasta "+ N);
        System.out.println("Numeros pares dedes 1 hasta " + N);
        
        for (j = 2; j <= N; j++){
        i = 2;
            while (j % i !=0){
            i++;
            }
            for ( p = 2 ; p <= N ; p += 2 ) {
            System.out.printf(" %d",p);
            if( i == j){
            System.out.println(j);
            if (i == p)
            System.out.println(p);
            
        
    }
            }
        }
    }        
    //Un programa en Java que te permita ingresar una palabra y la
    //imprima al rev�s.
    
    public static void Ejercicio4(){
    Scanner scanner = new Scanner (System.in);
    System.out.println("Introduccir palabra: ");
        }
}
        
        
        
        
    
            
    

